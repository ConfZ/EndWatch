/*

Commit Number: 8455d26243aef72f7b827ec0d8367b6b7816de07
URL: https://github.com/bminor/binutils-gdb/commit/8455d26243aef72f7b827ec0d8367b6b7816de07
Project Name: binutils-gdb
License: GPL2
termination: FALSE
*/
int main()
{
    int reg_count = __VERIFIER_nondet_int();
    if( reg_count > 65534)
        return 0;
    for( int i = 0 ; reg_count ; i++ )
    {
        //loop
    }
    return 0;
}
