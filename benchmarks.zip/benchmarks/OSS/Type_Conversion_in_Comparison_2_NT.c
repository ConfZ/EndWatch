/*

Commit Number: 34c30c8ad3725e0c4a7242278ff2606f422cff93
URL: https://github.com/asterisk/asterisk/commit/34c30c8ad3725e0c4a7242278ff2606f422cff93
Project Name: asterisk
License: GPL-2.0
termination: FALSE
*/
int main()
{
	unsigned long c1 = __VERIFIER_nondet_uchar();
	long c2 =  __VERIFIER_nondet_char();
	unsigned long ac;
	for( ac = c1 ; ac != c2 ; ac++ )
	{
        //do nothing;
	}
	return 0;
 }
