/*

Commit Number: d306f3d3513c62342fec4e31457766f2473f9e9a
URL: https://github.com/git/git/commit/d306f3d3513c62342fec4e31457766f2473f9e9a
Project Name: git
License: GPL-2.0
termination: FALSE
*/
int main()
{
    int number = __VERIFIER_nondet_int();
    int i, width;
    for( width = 1, i = 10 ; i <= number ; width++ )
        i *= 10;
    return 0;
}
