/*

Commit Number: 090341b0a95d1f6d762915a75c13b393366f4ab3
URL: https://github.com/torvalds/linux/commit/090341b0a95d1f6d762915a75c13b393366f4ab3
Project Name: linux
License: GPL-2.0
termination: FALSE
*/

int main()
{
    unsigned int mul,div1,div2;
    for( div1 = 1 ; div1 >= 0; div1-- )
    {
        for( div2 = 7; div2 >= 0 ; div2-- )
        {
            for( mul = 0 ; mul <= 255; mul++ )
            {
                //loop
            }
        }
    }
    return 0;
}
